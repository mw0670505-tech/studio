import io, json, tempfile, threading, unittest, urllib.request, zipfile
from pathlib import Path
import core
from app import AppServer, image_prompt_brief

class ImagePromptTests(unittest.TestCase):
 def test_brief_follows_article_and_sections(self):
  article=core.empty_article();article.update(title='Тихий угол',topic='Отдых собаки',body='Вступление о месте отдыха.\n\n## У прохода\n\nПроверьте коридор.\n\n## Размер\n\nСобаке нужно место.\n\n## Выход\n\nОставьте выход свободным.')
  brief=image_prompt_brief(article)
  for value in ('Тихий угол','Отдых собаки','У прохода','Проверьте коридор.','Размер','Выход','ОБЛОЖКА','ИЛЛЮСТРАЦИЯ 3'):
   self.assertIn(value,brief)
  self.assertNotIn('ИЛЛЮСТРАЦИЯ 4',brief)
 def test_empty_body_does_not_invent_illustrations(self):
  brief=image_prompt_brief(core.empty_article())
  self.assertIn('Добавьте текст статьи',brief)
  self.assertNotIn('ИЛЛЮСТРАЦИЯ 1',brief)
 def test_http_and_release_export(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=core.Store(Path(tmp)/'test.db');server=AppServer(('127.0.0.1',0),store)
   thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   try:
    base='http://127.0.0.1:'+str(server.server_port)
    article=core.empty_article();article.update(title='Заголовок',topic='Собака',body='## Раздел\n\nНаблюдайте за собакой.')
    saved=store.save(None,article)
    payload=json.dumps({'data':article}).encode()
    req=urllib.request.Request(base+'/api/visuals/prompts',payload,{'Content-Type':'application/json','X-Pets-CSRF':server.csrf})
    with urllib.request.urlopen(req) as response:brief=json.load(response)['text']
    with urllib.request.urlopen(base+'/api/export?id='+saved['id']) as response:
     with zipfile.ZipFile(io.BytesIO(response.read())) as archive:
      self.assertEqual(archive.read('image_prompts.txt').decode(),brief)
      self.assertIn('Наблюдайте за собакой.',brief)
   finally:server.shutdown();server.server_close();thread.join()
if __name__=='__main__':unittest.main()
