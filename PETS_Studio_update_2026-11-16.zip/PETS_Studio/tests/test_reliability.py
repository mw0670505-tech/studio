import copy
import hashlib
import io
import json
import tempfile
import threading
import unittest
import urllib.request
import zipfile
from pathlib import Path
from unittest.mock import patch

import core
import notion_sync
import workshop
from app import AppServer, full_backup_zip


class ReliabilityTests(unittest.TestCase):
    def test_full_backup_restores_all_assets_and_database(self):
        with tempfile.TemporaryDirectory() as tmp, tempfile.TemporaryDirectory() as restored:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            article = core.empty_article(); article['title'] = 'Материал для восстановления'
            saved = store.save(None, article)
            root = Path(tmp) / 'images'; root.mkdir()
            for i in range(501):
                (root / f'{i:03}.png').write_bytes(f'image-{i}'.encode())
            with zipfile.ZipFile(io.BytesIO(full_backup_zip(store))) as archive:
                manifest = json.loads(archive.read('PETS_FULL_BACKUP_MANIFEST.json'))
                self.assertEqual(manifest['asset_count'], 501)
                self.assertEqual(len(manifest['assets']), 501)
                for item in manifest['assets']:
                    data = archive.read(item['path'])
                    self.assertEqual(hashlib.sha256(data).hexdigest(), item['sha256'])
                archive.extractall(restored)
            result = core.Store(Path(restored) / 'data/studio.sqlite3')
            self.assertEqual(result.get(saved['id'])['data']['title'], article['title'])
            self.assertEqual(len(list((Path(restored) / 'data/images').iterdir())), 501)

    def test_partial_settings_preserve_consent(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            store.save_settings({'consent': True})
            store.save_settings({'notion_database_url': 'https://app.notion.com/p/' + 'a' * 32})
            self.assertTrue(store.settings()['consent'])
            store.save_settings({'consent': False})
            self.assertFalse(store.settings()['consent'])

    def test_backup_refuses_symlinked_image_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            images = Path(tmp) / 'images'; images.mkdir()
            (images / 'linked').symlink_to(Path(tmp), target_is_directory=True)
            with self.assertRaises(core.Problem):
                full_backup_zip(store)

    def test_research_cache_is_per_query(self):
        workshop._RESEARCH_CACHE.clear()
        def response(req, **kwargs):
            query = req.full_url.split('q=', 1)[1].split('&', 1)[0]
            return io.BytesIO(f'<rss><channel><item><title>{query}</title><link>https://example.org/{query}</link></item></channel></rss>'.encode())
        with patch('workshop.urllib.request.urlopen', side_effect=response) as request:
            first = workshop.current_topic_research('alpha')
            second = workshop.current_topic_research('beta')
            again = workshop.current_topic_research('alpha')
        self.assertEqual(request.call_count, 2)
        self.assertEqual(first['items'][0]['query'], 'alpha')
        self.assertEqual(second['items'][0]['query'], 'beta')
        self.assertEqual(again['items'], first['items'])


class FakeNotion:
    def __init__(self):
        self.page_id = 'a' * 32
        self.version = 1
        self.page = {'id': self.page_id, 'properties': {}, 'last_edited_time': '1'}
        self.blocks = [self.block('old1', 'first'), self.block('old2', 'second')]
        self.next_id = 0
        self.fail_delete = None
        self.change_on_read = False
        self.reads = 0

    @staticmethod
    def block(id, text):
        return {'id': id, 'type': 'paragraph', 'has_children': False,
                'paragraph': {'rich_text': [{'type': 'text', 'text': {'content': text}, 'plain_text': text}]}}

    def __call__(self, token, method, path, payload=None):
        if path == '/pages/' + self.page_id and method == 'GET':
            self.reads += 1
            if self.change_on_read and self.reads == 2:
                self.page['last_edited_time'] = 'changed'
            return copy.deepcopy(self.page)
        if path.startswith('/blocks/' + self.page_id + '/children') and method == 'GET':
            cursor = int(path.split('start_cursor=')[1]) if 'start_cursor=' in path else 0
            return {'results': copy.deepcopy(self.blocks[cursor:cursor+100]), 'has_more': len(self.blocks) > cursor+100, 'next_cursor': str(cursor+100) if len(self.blocks) > cursor+100 else None}
        if path == '/blocks/' + self.page_id + '/children' and method == 'PATCH':
            for item in payload['children']:
                self.next_id += 1
                b = copy.deepcopy(item); b['id'] = 'new' + str(self.next_id); b['has_children'] = False
                self.blocks.append(b)
            self.bump(); return {}
        if path.startswith('/blocks/') and method == 'DELETE':
            block_id = path.rsplit('/', 1)[1]
            if block_id == self.fail_delete:
                self.fail_delete = None
                raise core.Problem('synthetic failure', 502)
            self.blocks = [b for b in self.blocks if b['id'] != block_id]
            self.bump(); return {}
        if path == '/pages/' + self.page_id and method == 'PATCH':
            for name, value in payload['properties'].items():
                typ = next(iter(value)); self.page['properties'][name] = {'type': typ, typ: value[typ]}
            self.bump(); return copy.deepcopy(self.page)
        raise AssertionError((method, path))

    def bump(self):
        self.version += 1; self.page['last_edited_time'] = str(self.version)

    def text(self):
        return [''.join(t['text']['content'] for t in b[b['type']]['rich_text']) for b in self.blocks]


class NotionRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.store = core.Store(Path(self.tmp.name) / 'studio.sqlite3')
        self.fake = FakeNotion(); self.patch = patch('notion_sync._api', side_effect=self.fake); self.patch.start()

    def tearDown(self):
        self.patch.stop(); self.tmp.cleanup()

    def test_failure_during_delete_can_restore_backup(self):
        self.fake.fail_delete = 'old2'
        with self.assertRaises(core.Problem):
            notion_sync._safe_replace(self.store, 'test-token', self.fake.page_id, notion_sync._blocks('new content'), {}, '1')
        saved = notion_sync.backups(self.store)
        self.assertEqual(len(saved), 1)
        self.assertNotIn('test-token', json.dumps(notion_sync.backup_data(self.store, saved[0]['id'])))
        notion_sync.restore_backup(self.store, 'test-token', saved[0]['id'])
        self.assertEqual(self.fake.text(), ['first', 'second'])
        self.assertEqual(len(notion_sync.backups(self.store)), 2)
        with zipfile.ZipFile(io.BytesIO(full_backup_zip(self.store))) as z:
            self.assertIn('data/notion-backups/'+saved[0]['id']+'.json', z.namelist())

    def test_unsupported_block_is_not_deleted(self):
        self.fake.blocks.append({'id':'image', 'type':'image', 'has_children':False, 'image':{}})
        before = copy.deepcopy(self.fake.blocks)
        with self.assertRaises(core.Problem):
            notion_sync._safe_replace(self.store, 'x', self.fake.page_id, notion_sync._blocks('new'), {}, '1')
        self.assertEqual(self.fake.blocks, before)

    def test_concurrent_change_is_not_overwritten(self):
        self.fake.change_on_read = True
        with self.assertRaises(core.Problem) as ctx:
            notion_sync._safe_replace(self.store, 'x', self.fake.page_id, notion_sync._blocks('new'), {}, '1')
        self.assertEqual(ctx.exception.status, 409)
        self.assertEqual(self.fake.text(), ['first', 'second'])

    def test_pagination_and_long_text_are_not_truncated(self):
        self.fake.blocks = [self.fake.block(f'old{i}', f'old-{i}') for i in range(101)]
        body = '\n\n'.join(f'new-{i}' for i in range(101))
        notion_sync._safe_replace(self.store, 'x', self.fake.page_id, notion_sync._blocks(body), {}, '1')
        self.assertEqual(self.fake.text(), [f'new-{i}' for i in range(101)])
        self.assertEqual(len(notion_sync.backup_data(self.store, notion_sync.backups(self.store)[0]['id'])['blocks']), 101)

    def test_pull_preserves_local_evidence_and_metrics(self):
        local = core.empty_article(); local['claims'] = [{'anchor':'fact'}]; local['measurements'] = [{'window':'24h','impressions':1,'opens':1,'completions':1,'subscribers':0,'recorded_on':core.today(),'note':''}]
        with patch('notion_sync._read_blocks', return_value='body from notion'):
            imported = notion_sync.page_to_article('x', self.fake.page, local)
        self.assertEqual(imported['claims'][0]['anchor'], 'fact')
        self.assertEqual(imported['measurements'][0]['impressions'], 1)
        self.assertEqual(imported['body'], 'body from notion')

    def test_pull_preserves_evidence_but_resets_manual_checks_after_change(self):
        article = core.empty_article(); article['body'] = 'old body'
        article['claims'] = [{'anchor':'old body','verified':True}]
        article['gates'] = {k:True for k in core.GATES}; article['cover']['verified'] = True
        item = self.store.save(None, article)
        self.store.set_notion_meta(item['id'], {'page_id':self.fake.page_id, 'last_edited_time':'0', 'last_synced_fingerprint':core.fingerprint(article)})
        with patch('notion_sync.query', return_value=[self.fake.page]):
            notion_sync.sync(self.store, 'x', 'https://app.notion.com/p/' + 'b' * 32, 'pull')
        pulled = self.store.get(item['id'])['data']
        self.assertEqual(pulled['claims'][0]['anchor'], 'old body')
        self.assertFalse(pulled['claims'][0]['verified'])
        self.assertFalse(any(pulled['gates'].values()))
        self.assertFalse(pulled['cover']['verified'])

    def test_restore_reinstates_original_supported_properties(self):
        self.fake.page['properties']['Тема'] = {'type':'rich_text', 'rich_text':[{'type':'text','text':{'content':'original'},'plain_text':'original'}]}
        notion_sync._safe_replace(self.store, 'x', self.fake.page_id, notion_sync._blocks('replacement'), {'Тема':notion_sync._text('new')}, '1')
        saved = notion_sync.backups(self.store)[0]['id']
        notion_sync.restore_backup(self.store, 'x', saved)
        self.assertEqual(self.fake.page['properties']['Тема']['rich_text'][0]['text']['content'], 'original')


class NotionRecoveryHTTPTests(unittest.TestCase):
    def test_list_download_and_restore_routes(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = core.Store(Path(tmp) / 'studio.sqlite3')
            fake = FakeNotion()
            backup_id = notion_sync._snapshot(store, fake.page, fake.blocks)
            server = AppServer(('127.0.0.1', 0), store)
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
            base = 'http://127.0.0.1:' + str(server.server_port)
            try:
                with urllib.request.urlopen(base + '/api/notion/backups') as response:
                    self.assertEqual(json.load(response)[0]['id'], backup_id)
                with urllib.request.urlopen(base + '/api/notion/backup?id=' + backup_id) as response:
                    self.assertEqual(json.load(response)['page_id'], fake.page_id)
                request = urllib.request.Request(base + '/api/notion/restore', json.dumps({'id':backup_id}).encode(),
                    {'Content-Type':'application/json', 'X-Pets-CSRF':server.csrf})
                with patch('notion_sync.restore_backup', return_value={'message':'restored'}) as restore:
                    with urllib.request.urlopen(request) as response:self.assertEqual(json.load(response)['message'], 'restored')
                    restore.assert_called_once_with(store, '', backup_id)
            finally:
                server.shutdown(); server.server_close(); thread.join()
