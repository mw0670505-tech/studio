import copy
import io
import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import uuid
import zipfile
from pathlib import Path
from unittest.mock import patch

import core
import coderabbit_bridge as cb
from app import AppServer, full_backup_zip


class FakeAPI:
    """Synthetic upstream with the exact documented JSON shapes, no real tasks."""
    def __init__(self):
        self.calls = []
        self.owner = 'synthetic-owner'
        self.fail_submit = False
        self.status = 'completed'
        self.waiting = None
        self.remote_status = 'no_file_changes'
        self.text = json.dumps({'title':'Собака у двери: как устроить спокойный зимний выход',
                                'text':'## Перед выходом\n\nПодготовьте поводок и ключи.\n\n## Источники и ограничения\n\nОрганизационный пример.'}, ensure_ascii=False)

    def __call__(self, region, key, path, payload=None):
        self.calls.append((region, key, path, copy.deepcopy(payload)))
        if path == '/me':
            return {'principal':{'id':self.owner}, 'scope':{'id':'synthetic-org'}}
        if path.startswith('/repositories?'):
            return {'data':[{'id':'123456','full_name':cb.DEFAULTS['repository']}], 'next_cursor':None}
        if path == '/code/tasks?limit=1':
            return {'data': [], 'next_cursor': None}
        if path == '/code/tasks':
            if self.fail_submit:
                self.fail_submit = False
                raise core.Problem('Synthetic lost acknowledgment', 502)
            return {'task':{'task_id':'synthetic-task','repository_id':'123456','status':'queued'}, 'created':True}
        if path == '/code/tasks/synthetic-task':
            return {'task_id':'synthetic-task','repository_id':'123456','status':self.remote_status}
        if path.endswith('/turns'):
            return {'task_id':'synthetic-task','data':[{'start_seq':7,'status':self.status}], 'next_before_turn_start_seq':None}
        if path.endswith('/turns/7'):
            return {'start_seq':7,'status':self.status,'waiting_for_interaction_id':self.waiting,
                    'result':{'text':self.text} if self.status in ('completed','patch_ready') else None,'error':None}
        raise AssertionError(path)


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)/'test.sqlite3'
        self.store = core.Store(self.path)
        self.keys = {}
        self.bridge = cb.Bridge(self.store, self.keys)
        a = core.empty_article(); a['topic']='Зимняя прогулка с собакой'; a['gates'].update(facts=True,safety=True,rights=True)
        self.item = self.store.save(None, a)
        self.bridge.save_config({'api_key':'cr-SYNTHETIC-PRIVATE','consent':True,'preferred':True})
        self.upstream = FakeAPI()
        self.mock = patch('coderabbit_bridge.request',side_effect=self.upstream).start()
        self.addCleanup(patch.stopall)

    def tearDown(self):
        self.tmp.cleanup()

    def start(self, task='article', client_id=None):
        return self.bridge.start(self.item['id'],self.item['revision'],task,client_id or str(uuid.uuid4()))

    def test_official_submit_and_full_editorial_context_no_secrets(self):
        job=self.start()
        call=next(c for c in self.upstream.calls if c[2]=='/code/tasks');body=call[3]
        self.assertEqual(set(body),{'repository_id','branch','instructions','mode','is_private','client_request_id'})
        self.assertTrue(body['is_private']);self.assertEqual(body['repository_id'],'123456')
        self.assertIn('45–70',body['instructions']);self.assertIn('Зимняя прогулка',body['instructions'])
        self.assertNotIn('cr-SYNTHETIC-PRIVATE',body['instructions'])
        self.assertIn('/code/tasks/synthetic-task',job['url'])
        self.assertNotIn('instructions',job);self.assertIsNone(job['result'])
        self.assertEqual(self.store.get(self.item['id']),self.item)

    def test_no_consent_no_calls(self):
        self.bridge.save_config({'consent':False})
        with self.assertRaises(core.Problem):self.start()
        self.assertFalse(self.upstream.calls)

    def test_check_covers_tasks_and_does_not_create_any(self):
        self.assertTrue(self.bridge.check()['ok'])
        self.assertIn('/code/tasks?limit=1', [c[2] for c in self.upstream.calls])
        self.assertFalse(any(c[3] is not None for c in self.upstream.calls))

    def test_task_permission_denied_before_submit_retry_survives(self):
        def denied(region, key, path, payload=None):
            if path == '/code/tasks?limit=1':
                raise core.Problem('Coding Agent HTTP 403', 502)
            return self.upstream(region, key, path, payload)
        self.mock.side_effect = denied
        with self.assertRaises(core.Problem): self.bridge.check()
        cid = str(uuid.uuid4())
        with self.assertRaises(core.Problem): self.start(client_id=cid)
        self.assertEqual(self.bridge.jobs(self.item['id'])[0]['status'], 'prepared')
        self.assertFalse(any(c[3] is not None for c in self.upstream.calls))
        self.mock.side_effect = self.upstream
        reopened = cb.Bridge(core.Store(self.path), self.keys)
        self.assertEqual(reopened.retry(cid)['status'], 'queued')
        payloads = [c[3] for c in self.upstream.calls if c[3] is not None]
        self.assertEqual(len(payloads), 1)
        self.assertEqual(payloads[0]['client_request_id'], 'pets-' + cid)

    def test_topics_result_saved_explicitly_without_changing_article(self):
        idea = {'title_working':'Собака и велосипедный шлем: куда убрать экипировку после поездки',
                'reader_question':'Где хранить экипировку?', 'promise':'Организовать хранение вещей',
                'rubric':'HOME', 'risk':'GREEN'}
        self.upstream.text = json.dumps({'topics': [idea]})
        before = self.store.topics()
        job = self.start('topics')
        submitted = next(c[3] for c in self.upstream.calls if c[3] is not None)
        self.assertIn('existing_topics', submitted['instructions'])
        self.assertIn('Зимняя прогулка', submitted['instructions'])
        self.assertEqual(self.bridge.poll(job['id'])['status'], 'ready')
        self.assertEqual(self.store.topics(), before)
        a = self.item['data']; a['title'] = 'Правка во время ожидания'
        changed = self.store.save(self.item['id'], a, self.item['revision'])
        saved = self.bridge.save_topics(job['id'])
        self.assertEqual(saved['status'], 'applied')
        self.assertEqual(len(self.store.topics()), len(before) + 1)
        self.assertEqual(self.store.get(self.item['id']), changed)
        self.assertEqual(self.bridge.save_topics(job['id']), saved)
        self.assertEqual(len(self.store.topics()), len(before) + 1)

    def test_topics_duplicate_rechecked_at_import_and_bad_result_rejected(self):
        idea = {'title_working':'Хранение светоотражающего жилета после вечернего маршрута',
                'reader_question':'Куда убрать жилет?', 'promise':'Выбрать доступное место',
                'rubric':'HOME', 'risk':'GREEN'}
        self.upstream.text = json.dumps({'topics': [idea]})
        job = self.start('topics'); self.bridge.poll(job['id'])
        self.store.offer_topics(cb.topic_engine.validate({'topics':[idea]}), generated=True)
        before = self.store.topics()
        self.assertEqual(self.bridge.save_topics(job['id'])['result']['topics'], [])
        self.assertEqual(self.store.topics(), before)
        self.upstream.text = '{"topics":[{"title_working":"incomplete"}]}'
        job = self.start('topics')
        self.assertEqual(self.bridge.poll(job['id'])['status'], 'invalid_result')
        with self.assertRaises(core.Problem): self.bridge.save_topics(job['id'])

    def test_oversize_prompt_never_truncated_or_sent(self):
        a=self.item['data'];a['body']='А😀'*40000;self.item=self.store.save(self.item['id'],a,self.item['revision'])
        with self.assertRaises(core.Problem):self.start()
        self.assertFalse(self.upstream.calls)

    def test_stale_revision_never_sends(self):
        self.store.save(self.item['id'],self.item['data'],self.item['revision'])
        with self.assertRaises(core.Problem):self.start()
        self.assertFalse(self.upstream.calls)

    def test_lost_ack_retry_survives_restart_exact_payload(self):
        self.upstream.fail_submit=True
        job=self.start();self.assertEqual(job['status'],'uncertain')
        self.bridge=cb.Bridge(core.Store(self.path),self.keys)
        retried=self.bridge.retry(job['id']);self.assertEqual(retried['status'],'queued')
        submissions=[c[3] for c in self.upstream.calls if c[2]=='/code/tasks']
        self.assertEqual(len(submissions),2);self.assertEqual(submissions[0],submissions[1])
        self.bridge.retry(job['id']);self.assertEqual(len([c for c in self.upstream.calls if c[2]=='/code/tasks']),2)

    def test_duplicate_browser_submission_does_not_start_again(self):
        cid=str(uuid.uuid4());first=self.start(client_id=cid);second=self.start(client_id=cid)
        self.assertEqual(first['id'],second['id']);self.assertEqual(len([c for c in self.upstream.calls if c[2]=='/code/tasks']),1)
        with self.assertRaises(core.Problem):self.start()

    def test_retry_cannot_switch_owner(self):
        self.upstream.fail_submit=True;job=self.start();self.upstream.owner='different-owner'
        self.bridge.save_config({'api_key':'cr-OTHER-SYNTHETIC'})
        with self.assertRaises(core.Problem):self.bridge.retry(job['id'])
        self.assertEqual(len([c for c in self.upstream.calls if c[2]=='/code/tasks']),1)

    def test_exact_first_turn_safe_result_and_explicit_apply(self):
        raw=json.loads(self.upstream.text);raw.update(gates={'facts':True},approval='fake',claims=[{'verified':True}],visuals=[{'file':'secret'}])
        self.upstream.text=json.dumps(raw)
        job=self.start();ready=self.bridge.poll(job['id']);self.assertEqual(ready['status'],'ready')
        self.assertNotIn('gates',ready['result']);self.assertNotIn('claims',ready['result']);self.assertNotIn('visuals',ready['result'])
        self.assertEqual(self.store.get(self.item['id']),self.item)
        applied=self.bridge.apply(job['id']);self.assertIn('Подготовьте поводок',applied['data']['body'])
        self.assertTrue(all(not v for v in applied['data']['gates'].values()));self.assertIsNone(applied['approval'])
        self.assertEqual(self.bridge.apply(job['id'])['revision'],applied['revision'])
        self.assertTrue(self.store.history(self.item['id']))

    def test_edit_while_waiting_cannot_be_overwritten(self):
        job=self.start();self.bridge.poll(job['id'])
        a=self.item['data'];a['title']='Моя новая правка';saved=self.store.save(self.item['id'],a,self.item['revision'])
        with self.assertRaises(core.Problem) as e:self.bridge.apply(job['id'])
        self.assertEqual(e.exception.status,409);self.assertEqual(self.store.get(self.item['id']),saved)

    def test_poll_throttle_and_revoked_consent(self):
        self.upstream.status='running';job=self.start();self.bridge.poll(job['id']);n=len(self.upstream.calls)
        self.bridge.poll(job['id']);self.assertEqual(len(self.upstream.calls),n)
        self.bridge.save_config({'consent':False});self.bridge.poll(job['id']);self.assertEqual(len(self.upstream.calls),n)

    def test_question_attention_and_resume_same_task(self):
        self.upstream.status='running';self.upstream.waiting='synthetic-question';job=self.start()
        self.assertEqual(self.bridge.poll(job['id'])['status'],'needs_attention')
        self.upstream.status='completed';self.upstream.waiting=None
        self.assertEqual(self.bridge.resume(job['id'])['status'],'ready')
        self.assertEqual(len([c for c in self.upstream.calls if c[2]=='/code/tasks']),1)

    def test_failure_and_bad_reply_never_apply(self):
        for status in ('failed','canceled'):
            self.upstream.status=status;job=self.start()
            self.assertEqual(self.bridge.poll(job['id'])['status'],'failed')
            with self.assertRaises(core.Problem):self.bridge.apply(job['id'])
        self.upstream.status='completed';self.upstream.text='Статья в файле /tmp/article.md'
        job=self.start();self.assertEqual(self.bridge.poll(job['id'])['status'],'invalid_result')
        with self.assertRaises(core.Problem):self.bridge.apply(job['id'])
        self.assertEqual(self.store.get(self.item['id']),self.item)

    def test_clinical_result_is_held(self):
        self.upstream.text=json.dumps({'text':'Давайте собаке 5 мг/кг.'})
        job=self.start();self.assertEqual(self.bridge.poll(job['id'])['status'],'hold')
        with self.assertRaises(core.Problem):self.bridge.apply(job['id'])

    def test_keywords_title_and_outline_apply(self):
        for task,result,field in [('titles',{'titles':['Новый конкретный заголовок']},'title'),
                                  ('keywords',{'keywords':['зимняя прогулка']},'keywords'),
                                  ('outline',{'text':'Конкретный план для прогулки'},'brief')]:
            self.item=self.store.get(self.item['id']);self.upstream.text=json.dumps(result)
            job=self.start(task);self.bridge.poll(job['id']);applied=self.bridge.apply(job['id'],0 if task=='titles' else None)
            self.assertNotEqual(applied['data'][field],self.item['data'][field])

    def test_public_config_database_and_full_backup_have_no_key(self):
        self.start();secret=b'cr-SYNTHETIC-PRIVATE'
        self.assertNotIn(secret,self.path.read_bytes())
        self.assertNotIn(secret,json.dumps(self.bridge.public_config()).encode())
        with zipfile.ZipFile(io.BytesIO(full_backup_zip(self.store))) as z:
            for name in z.namelist():self.assertNotIn(secret,z.read(name),name)

    def test_api_region_and_config_validation(self):
        for value in ({'region':'https://evil.example'},{'region':[]},{'repository':'../secret'},{'branch':'\n'},{'api_key':'bad\r\nkey'}):
            before=self.bridge.public_config()
            with self.assertRaises(core.Problem):self.bridge.save_config(value)
            self.assertEqual(before,self.bridge.public_config())
        self.bridge.save_config({'region':'eu'});self.assertEqual(self.bridge.public_config()['region'],'eu')
        job=self.start();self.assertTrue(job['url'].startswith('https://app.eu.coderabbit.ai/'))

    def test_completed_task_without_turns_requires_attention(self):
        job=self.start()
        def without_turns(region,key,path,payload=None):
            if path.endswith('/turns'):
                return {'task_id':'synthetic-task','data':[],'next_before_turn_start_seq':None}
            return self.upstream(region,key,path,payload)
        self.mock.side_effect=without_turns
        self.assertEqual(self.bridge.poll(job['id'])['status'],'needs_attention')

    def test_first_turn_is_preserved_when_later_turns_appear(self):
        job=self.start()
        def with_later_turn(region,key,path,payload=None):
            if path.endswith('/turns'):
                return {'task_id':'synthetic-task','data':[{'start_seq':7},{'start_seq':50}],'next_before_turn_start_seq':None}
            return self.upstream(region,key,path,payload)
        self.mock.side_effect=with_later_turn
        self.assertEqual(self.bridge.poll(job['id'])['status'],'ready')
        self.assertFalse(any(call[2].endswith('/50') for call in self.upstream.calls))

    def test_wrong_remote_task_never_applies(self):
        job=self.start()
        def wrong_task(region,key,path,payload=None):
            if path=='/code/tasks/synthetic-task':
                return {'task_id':'different-task','repository_id':'123456','status':'completed'}
            return self.upstream(region,key,path,payload)
        self.mock.side_effect=wrong_task
        self.assertEqual(self.bridge.poll(job['id'])['status'],'queued')
        with self.assertRaises(core.Problem):self.bridge.apply(job['id'])

    def test_oversize_title_never_becomes_applicable(self):
        self.upstream.text=json.dumps({'text':'Черновик','title':'А'*3001})
        job=self.start()
        self.assertEqual(self.bridge.poll(job['id'])['status'],'invalid_result')


class TransportTests(unittest.TestCase):
    def test_tasks_forbidden_known_reason_is_safe_and_bounded(self):
        for body, reconnect in (({'error':{'message':'Reconnect the API key owner GitHub account. SECRET cr-FAKE'}}, True),
                                ({'message':'Other SECRET cr-FAKE'}, False)):
            error=urllib.error.HTTPError('https://official.example',403,'forbidden',{},io.BytesIO(json.dumps(body).encode()))
            with patch('coderabbit_bridge.urllib.request.build_opener') as opener:
                opener.return_value.open.side_effect=error
                with self.assertRaises(core.Problem) as ctx: cb.request('us','cr-FAKE','/code/tasks?limit=1')
            self.assertEqual('заново' in str(ctx.exception), reconnect)
            self.assertIn('HTTP 403', str(ctx.exception))
            self.assertNotIn('SECRET', str(ctx.exception)); self.assertNotIn('cr-FAKE', str(ctx.exception))

    def test_official_headers_endpoint_and_redirect_policy(self):
        response=io.BytesIO(b'{"ok":true}')
        with patch('coderabbit_bridge.urllib.request.build_opener') as opener:
            opener.return_value.open.return_value=response
            self.assertTrue(cb.request('eu','cr-FAKE','/me')['ok'])
            req=opener.return_value.open.call_args.args[0]
            self.assertEqual(req.full_url,'https://api.eu.coderabbit.ai/v1/me')
            self.assertEqual(req.get_header('X-coderabbitai-api-key'),'cr-FAKE')
            self.assertEqual(req.get_header('User-agent'),'PETS-Studio/3.1.3')
            self.assertIs(opener.call_args.args[0],cb.NoRedirect)
            self.assertIsNone(cb.NoRedirect().redirect_request(req,None,302,'',{},'https://evil.example'))

    def test_provider_errors_are_sanitized(self):
        for code in (301,401,403,404,429,500):
            error=urllib.error.HTTPError('https://official.example',code,'secret cr-FAKE',{},io.BytesIO(b'SECRET BODY'))
            with patch('coderabbit_bridge.urllib.request.build_opener') as opener:
                opener.return_value.open.side_effect=error
                with self.assertRaises(core.Problem) as e:cb.request('us','cr-FAKE','/me')
                self.assertNotIn('SECRET',str(e.exception));self.assertNotIn('cr-FAKE',str(e.exception))

    def test_forbidden_identifies_read_stage_without_exposing_provider_body(self):
        for path, expected in (('/me', 'учётной записи'),
                               ('/repositories?full_name=owner%2Frepo', 'списка репозиториев')):
            with self.subTest(path=path):
                error=urllib.error.HTTPError('https://official.example',403,'secret cr-FAKE',{},io.BytesIO(b'SECRET BODY'))
                with patch('coderabbit_bridge.urllib.request.build_opener') as opener:
                    opener.return_value.open.side_effect=error
                    with self.assertRaises(core.Problem) as ctx:cb.request('us','cr-FAKE',path)
                self.assertEqual(ctx.exception.status,502)
                self.assertIn(expected,str(ctx.exception))
                self.assertIn('HTTP 403',str(ctx.exception))
                self.assertNotIn('SECRET',str(ctx.exception))
                self.assertNotIn('cr-FAKE',str(ctx.exception))

    def test_oversize_and_nonobject_response_rejected(self):
        for body in (b'x'*(cb.MAX_RESPONSE+1),b'[]',b'not json'):
            with patch('coderabbit_bridge.urllib.request.build_opener') as opener:
                opener.return_value.open.return_value=io.BytesIO(body)
                with self.assertRaises(core.Problem):cb.request('us','cr-FAKE','/me')


class BridgeHTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=core.Store(Path(self.tmp.name)/'http.sqlite3')
        self.server=AppServer(('127.0.0.1',0),self.store);self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base='http://127.0.0.1:'+str(self.server.server_port)
        self.fake=FakeAPI();self.patch=patch('coderabbit_bridge.request',side_effect=self.fake);self.patch.start()

    def tearDown(self):
        self.patch.stop();self.server.shutdown();self.server.server_close();self.thread.join();self.tmp.cleanup()

    def req(self,path,data=None,csrf=None):
        req=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,
                                  headers={'Content-Type':'application/json','X-Pets-CSRF':self.server.csrf if csrf is None else csrf})
        with urllib.request.urlopen(req,timeout=10) as r:return json.load(r)

    def test_config_key_check_bootstrap_and_recovery(self):
        self.req('/api/coderabbit/config',{'api_key':'cr-HTTP-SYNTHETIC','consent':True,'preferred':True,'remember_key':True})
        self.assertTrue(self.req('/api/coderabbit/check',{})['ok'])
        boot=self.req('/api/bootstrap');self.assertTrue(boot['coderabbit']['configured']);self.assertNotIn('cr-HTTP',json.dumps(boot))
        persisted=self.server.local_keys_path.read_text();self.assertIn('cr-HTTP-SYNTHETIC',persisted)
        item=self.store.list_articles()[0];full=self.store.get(item['id'])
        job=self.req('/api/coderabbit/start',{'article_id':item['id'],'revision':full['revision'],'task':'article','client_id':str(uuid.uuid4())})
        self.assertEqual(self.req('/api/coderabbit/poll',{'id':job['id']})['status'],'ready')
        self.assertEqual(len(self.req('/api/coderabbit/jobs?article_id='+item['id'])),1)
        applied=self.req('/api/coderabbit/apply',{'id':job['id']});self.assertIn('Подготовьте поводок',applied['data']['body'])
        self.req('/api/coderabbit/config',{'forget_key':True});self.assertFalse(self.req('/api/bootstrap')['coderabbit']['configured']);self.assertFalse(self.server.local_keys_path.exists())

    def test_csrf_protects_connector_mutations(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.req('/api/coderabbit/config',{'api_key':'secret'},csrf='wrong')
        self.assertEqual(e.exception.code,403);self.assertFalse(self.server.keys)

    def test_missing_key_and_unsupported_endpoint_fail_cleanly(self):
        with self.assertRaises(urllib.error.HTTPError):self.req('/api/coderabbit/check',{})
        self.assertFalse(self.fake.calls)
        with self.assertRaises(urllib.error.HTTPError):self.req('/api/coderabbit/apply',{'id':{}})
