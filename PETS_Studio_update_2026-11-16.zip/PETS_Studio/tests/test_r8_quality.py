import tempfile, unittest
from pathlib import Path
from core import Store, empty_article, generation_guard, generation_prompt

class R8QualityTests(unittest.TestCase):
    def test_curated_project_pack_is_active_and_budgeted(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'studio.sqlite3')
            manifest=store.context_manifest()
            names={x['name'] for x in manifest['documents']}
            self.assertEqual(names, {'PETS / 01_CORE.md','PETS / 02_VOICE.md','PETS / 03_SAFETY.md'})
            self.assertLessEqual(len(store.context()),60000)
            self.assertIn('не выдумывай',store.context().lower())
            self.assertIn('дозиров',store.context())

    def test_guard_blocks_bad_provider_article(self):
        a=empty_article()
        a.update(title='Проверка',topic='Поведение собаки')
        bad={'text':'```json\n{"text":"гарантированно поможет"}\n```'}
        result=generation_guard('article',bad,a,{'min_chars':6000,'max_chars':8000})
        self.assertTrue(result['hold'])
        codes={x['code'] for x in result['guard']['issues']}
        self.assertIn('LENGTH',codes)
        self.assertIn('PROMISE',codes)
        self.assertIn('LEAKED_FORMAT',codes)

    def test_article_guard_requires_readable_markdown(self):
        a=empty_article()
        a.update(title='Проверка',topic='Поведение собаки')
        body=' '.join(['Наблюдение владельца и проверяемый контекст без категоричных выводов.']*500)
        result=generation_guard('article',{'text':body},a,{'min_chars':6000,'max_chars':8000})
        codes={x['code'] for x in result['guard']['issues']}
        self.assertIn('MARKDOWN_STRUCTURE',codes)
        self.assertIn('SOURCES_SECTION',codes)

    def test_review_notes_are_passed_to_prompt(self):
        a=empty_article()
        a['review_notes']='Проверить обещание заголовка и добавить ограничения.'
        self.assertIn('Проверить обещание заголовка',generation_prompt('rewrite',a,'',{}))

    def test_chat_is_in_backup_and_restore_is_non_destructive(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'studio.sqlite3')
            session=store.chat_create('Редакторский чат')
            store.chat_append(session['id'],'user','Проверить тему')
            store.chat_append(session['id'],'assistant','Нужны источники и новый угол.')
            backup=store.backup()
            self.assertEqual(len(backup['chat_sessions']),1)
            self.assertEqual(len(backup['chat_messages']),2)
            result=store.restore(backup)
            self.assertEqual(result['chats'],1)
            self.assertEqual(result['chat_messages'],2)
            self.assertEqual(len(store.chat_sessions()),2)

if __name__=='__main__': unittest.main()
