import tempfile
import unittest
from pathlib import Path

from core import Problem, Store


class EditorialDeskSettingsTests(unittest.TestCase):
    def test_personal_goal_preserves_legacy_history_and_consent(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'studio.sqlite3')
            store.save_settings({'consent': True})
            store.motivation_action('focus', 'legacy-article')
            before = store.settings()['motivation']
            saved = store.save_settings({'motivation': {'personal_goal': '  Подготовить два материала  '}})
            self.assertEqual(saved['motivation']['personal_goal'], 'Подготовить два материала')
            self.assertEqual(saved['motivation']['events'], before['events'])
            self.assertEqual(saved['motivation']['action_keys'], before['action_keys'])
            self.assertEqual(saved['motivation']['sparks'], before['sparks'])
            self.assertTrue(saved['consent'])
            cleared = store.save_settings({'motivation': {'personal_goal': ''}})
            self.assertEqual(cleared['motivation']['personal_goal'], '')
            self.assertEqual(cleared['motivation']['events'], before['events'])

    def test_invalid_goal_does_not_change_settings(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'studio.sqlite3')
            before = store.settings()
            for value in (None, ['x'], 'x' * 161):
                with self.assertRaises(Problem):
                    store.save_settings({'motivation': {'personal_goal': value}})
            self.assertEqual(store.settings(), before)

if __name__ == '__main__':
    unittest.main()
