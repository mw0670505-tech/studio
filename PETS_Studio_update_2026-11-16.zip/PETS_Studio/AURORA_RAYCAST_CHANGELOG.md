# PETS Studio — Aurora Raycast update

Дата: 2026-11-14

## Что изменено

- Добавлен отдельный визуальный слой `web/aurora-raycast.css`.
- Включена тёмная navy-схема Aurora Raycast.
- Добавлены полупрозрачные поверхности, мягкие границы и аккуратные blue/cyan акценты.
- Обновлены sidebar, topbar, кнопки, карточки, editor, QC, chat, settings и modal-элементы.
- Основная логика, API routes, SQLite, статьи, резервное копирование и тесты не изменялись.
- Исправлен static route в `app.py`, чтобы новый CSS корректно отдавался приложением.
- Мобильная версия проверена на ширине 390 px: горизонтального overflow нет.

## Проверка

- `python -m unittest discover -s tests -v`
- 134 теста пройдено.
- Desktop QA: 1440 px.
- Mobile QA: 390 px.

## Резервная копия

Оригинальный архив до визуального обновления сохранён в:

`backups/PETS_STUDIO_R11_3_HARDENED_ORIGINAL.zip`
